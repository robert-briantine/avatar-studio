import assert from "node:assert/strict";
import test from "node:test";
import { buildWanS2VExtendedWorkflow, buildWanS2VStabilizedWorkflow } from "../src/wanS2V.js";
import type { PromptGraph } from "../src/workflows.js";

const input = {
  imageName: "reference.png", audioName: "speech.wav", prompt: "",
  strictIdentity: true, seed: 123456
};

// Follow the latent all the way to the decoder. Temporal extensions must never
// multiply the number of independent videos, even for a long narration.
function latentShape(graph: PromptGraph, id: string): { batch: number; blocks: number } {
  const node = graph[id];
  const linked = (name: string) => latentShape(graph, (node.inputs[name] as [string, number])[0]);
  switch (node.class_type) {
    case "WanSoundImageToVideo": return { batch: Number(node.inputs.batch_size), blocks: 1 };
    case "WanSoundImageToVideoExtend": return { batch: linked("video_latent").batch, blocks: 1 };
    case "KSampler": return linked("latent_image");
    case "LatentConcat": {
      assert.equal(node.inputs.dim, "t");
      const a = linked("samples1"), b = linked("samples2");
      assert.equal(a.batch, b.batch);
      return { batch: a.batch, blocks: a.blocks + b.blocks };
    }
    default: throw new Error(`Unexpected latent node: ${node.class_type}`);
  }
}

for (const [durationSeconds, expectedBlocks] of [[1, 1], [77 / 16, 1], [78 / 16, 2], [10, 3], [60, 13]]) {
  test(`one output video covering ${durationSeconds}s of audio`, () => {
    const { graph, chunks, generatedFrames } = buildWanS2VExtendedWorkflow({ ...input, durationSeconds });
    const nodes = Object.values(graph);
    assert.equal(chunks, expectedBlocks);
    assert.ok(generatedFrames >= Math.ceil(durationSeconds * 16));
    assert.ok(generatedFrames - Math.ceil(durationSeconds * 16) < 77);
    const decoders = nodes.filter(node => node.class_type === "VAEDecode");
    assert.equal(decoders.length, 1);
    const latentId = (decoders[0].inputs.samples as [string, number])[0];
    assert.deepEqual(latentShape(graph, latentId), { batch: 1, blocks: expectedBlocks });
    assert.equal(nodes.filter(node => node.class_type === "AudioEncoderEncode").length, 1);
    assert.equal(nodes.filter(node => node.class_type === "SaveVideo").length, 1);
    const video = nodes.find(node => node.class_type === "CreateVideo")!;
    const audioId = (video.inputs.audio as [string, number])[0];
    assert.equal(graph[audioId].inputs.audio, "speech.wav");
    assert.equal(video.inputs.fps, 16);
    for (const node of nodes) {
      for (const value of Object.values(node.inputs)) {
        if (Array.isArray(value)) assert.ok(graph[value[0]], `Missing input node ${value[0]}`);
      }
      if (node.class_type === "KSampler") {
        assert.equal(node.inputs.steps, 20);
        assert.equal(node.inputs.cfg, 6);
        assert.equal(node.inputs.seed, input.seed);
        assert.equal(node.inputs.sampler_name, "uni_pc");
      }
      if (node.class_type === "WanSoundImageToVideo") {
        assert.equal(node.inputs.width, 768);
        assert.equal(node.inputs.height, 432);
      }
    }
  });
}

test("explicit quality and identity settings survive every extension", () => {
  const { graph } = buildWanS2VExtendedWorkflow({
    ...input, durationSeconds: 12, steps: 28, cfg: 5.5,
    width: 832, height: 480, filenamePrefix: "test/custom"
  });
  for (const node of Object.values(graph)) {
    if (node.class_type === "KSampler") {
      assert.equal(node.inputs.steps, 28);
      assert.equal(node.inputs.cfg, 5.5);
      const conditioning = graph[(node.inputs.positive as [string, number])[0]];
      const text = graph[(conditioning.inputs.positive as [string, number])[0]];
      assert.equal(text.inputs.text, "");
      const reference = graph[(conditioning.inputs.ref_image as [string, number])[0]];
      assert.equal(reference.inputs.image, input.imageName);
      const negative = graph[(conditioning.inputs.negative as [string, number])[0]];
      assert.match(String(negative.inputs.text), /identity change/);
    }
    if (node.class_type === "SaveVideo") assert.equal(node.inputs.filename_prefix, "test/custom");
  }
});

test("stabilization preserves the existing workflow for short videos", () => {
  for (const durationSeconds of [1, 6, 154 / 16]) {
    const args = { ...input, durationSeconds };
    assert.deepEqual(buildWanS2VStabilizedWorkflow(args), buildWanS2VExtendedWorkflow(args));
  }
});

for (const durationSeconds of [155 / 16, 300 / 16, 301 / 16, 24, 53.657, 60, 60.013]) {
  test(`stabilization bounds drift and preserves the audio timeline for ${durationSeconds}s`, () => {
    const { graph, chunks, windows } = buildWanS2VStabilizedWorkflow({ ...input, durationSeconds });
    const nodes = Object.values(graph);
    const requestedFrames = Math.ceil(durationSeconds * 16);
    const crops = nodes.filter(node => node.class_type === "ImageFromBatch");
    const trims = nodes.filter(node => node.class_type === "TrimAudioDuration");
    assert.equal(crops.length, trims.length);
    assert.ok(windows && windows.length === trims.length);
    assert.equal(chunks, crops.reduce((sum, crop) => sum + Math.ceil(Number(crop.inputs.length) / 77), 0));
    assert.equal(nodes.filter(node => node.class_type === "KSampler").length, chunks);
    let elapsedFrames = 0;
    for (let i = 0; i < crops.length; i++) {
      if (i > 0) elapsedFrames -= 8;
      assert.equal(trims[i].inputs.start_index, elapsedFrames / 16);
      const frames = Number(crops[i].inputs.length);
      assert.deepEqual(windows[i], { startFrame: elapsedFrames, frames });
      assert.equal(trims[i].inputs.duration, frames / 16);
      assert.ok(frames > 0 && frames <= 154);
      const decoder = graph[(crops[i].inputs.image as [string, number])[0]];
      const latent = latentShape(graph, (decoder.inputs.samples as [string, number])[0]);
      assert.equal(latent.batch, 1);
      assert.equal(latent.blocks, Math.ceil(frames / 77));
      assert.ok(latent.blocks <= 2, "motion must never propagate beyond two blocks");
      elapsedFrames += frames;
    }
    assert.equal(elapsedFrames, requestedFrames);
    // The images, not latent histories, are joined across reset boundaries.
    const video = nodes.find(node => node.class_type === "CreateVideo")!;
    const imageCount = (id: string): number => {
      const node = graph[id];
      if (node.class_type === "ImageFromBatch") return Number(node.inputs.length);
      assert.equal(node.class_type, "ImageBatch");
      return imageCount((node.inputs.image1 as [string, number])[0]) + imageCount((node.inputs.image2 as [string, number])[0]);
    };
    assert.equal(imageCount((video.inputs.images as [string, number])[0]), requestedFrames + 8 * (crops.length - 1));
    // Audio is muxed only after the duplicated overlap frames are merged.
    assert.equal(video.inputs.audio, undefined);
    for (const type of ["LoadAudio", "LoadImage", "UNETLoader", "CLIPLoader", "AudioEncoderLoader", "SaveVideo"]) {
      assert.equal(nodes.filter(node => node.class_type === type).length, 1, `${type} must stay shared`);
    }
    const encodedAudioSources = new Set(nodes.filter(node => node.class_type === "AudioEncoderEncode")
      .map(node => (node.inputs.audio as [string, number])[0]));
    assert.equal(encodedAudioSources.size, trims.length);
    for (const node of nodes) {
      for (const value of Object.values(node.inputs)) {
        if (Array.isArray(value)) assert.ok(graph[value[0]], `Missing node ${value[0]}`);
      }
      if (node.class_type === "KSampler") {
        assert.equal(node.inputs.steps, 20);
        assert.equal(node.inputs.cfg, 6);
        const conditioning = graph[(node.inputs.positive as [string, number])[0]];
        const reference = graph[(conditioning.inputs.ref_image as [string, number])[0]];
        assert.equal(reference.inputs.image, input.imageName);
      }
    }
  });
}
