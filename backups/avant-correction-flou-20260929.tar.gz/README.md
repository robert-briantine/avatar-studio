# DGX Avatar Studio v0.4.0

Application locale DGX Spark : image Qwen, voix Qwen3-TTS et vidéo Wan2.2-S2V.

## Optimisation vidéo — septembre 2026

- Correction du batch Wan : une seule vidéo est calculée, puis prolongée avec les
  blocs Extend. Auparavant, le nombre de blocs était aussi utilisé comme nombre
  de vidéos indépendantes : une narration de 10 s (3 blocs) calculait 3 variantes
  à chaque passe, alors qu'une seule était utilisée dans la vidéo finale.
- Les réglages de qualité sont conservés : profil Normal à 768×432, 20 étapes,
  CFG 6 et 16 fps, avec les mêmes modèles, prompts et références de visage.
- `start.sh` utilise désormais le cache natif de ComfyUI. Avec la version installée
  (0.28.2), ce cache s'adapte à la pression mémoire. L'application ne force plus
  son vidage avant chaque vidéo ; ComfyUI reste responsable de l'éviction des
  modèles lorsque la mémoire manque.
- Les workers lancés par `scripts/start-benchmark-workers.sh` conservent leur
  réglage `--cache-none` ; la correction du batch s'applique aussi au benchmark.

Relancer l'application avec `./start.sh` pour appliquer les changements. Une
instance ComfyUI déjà active est réutilisée avec ses paramètres de démarrage
actuels ; le réglage du cache s'applique lorsque `start.sh` démarre ComfyUI.
Le fichier `.env` existant n'a pas besoin d'être remplacé.

Pour retrouver la gestion mémoire précédente, ajouter dans `.env` puis relancer :

```dotenv
COMFY_CACHE_MODE=none
WAN_FREE_MEMORY_BEFORE_VIDEO=true
```

Les sources et fichiers compilés d'origine sont sauvegardés dans
`backups/avant-optimisation-video-20260929.tar.gz`. Les projets et médias persistants
ne sont pas modifiés par cette mise à jour. Les tests de non-régression du workflow
s'exécutent avec `npm test`, et la compilation avec `npm run build`.

Vérification sur le DGX Spark GB10 le 29 septembre 2026 : compilation réussie,
6 tests de non-régression réussis, import d'avatar et routes de l'application
vérifiés dans un stockage temporaire. Une vraie génération GPU de 6 s avec
2 blocs Extend a produit un MP4 H.264/AAC à 16 fps, son et vidéo de 6 s, entièrement
décodable. Le service TTS n'a pas été lancé pour ces tests à partir d'un WAV.

Comparaison supplémentaire avec GPU déjà chargé, mêmes image, WAV et seed,
cache natif activé dans les deux cas, **256×144 et 4 étapes** :

| Batch Wan | Temps de génération mesuré |
| --- | ---: |
| Ancien comportement : 2 vidéos pour 2 blocs | 39,144 s |
| Correctif : 1 vidéo pour 2 blocs | 20,064 s |

Soit environ 49 % de temps en moins sur ce petit test. Il valide les extensions
et la réutilisation du cache, mais ne mesure pas le gain au profil Normal et
ne constitue pas une évaluation visuelle à 20 étapes. Les réglages de qualité
sont conservés ; un changement de batch peut toutefois modifier le rendu pour
un même seed. Les vidéos d'un seul bloc ne bénéficient pas de la correction du
batch ; le cache peut accélérer leurs générations successives.

## Jobs persistants

Les générations image, voix, vidéo test et Wan2.2 sont maintenant lancées comme des **jobs côté serveur**.

- La requête HTTP répond immédiatement avec un job.
- Fermer ou recharger l'onglet navigateur n'arrête pas la génération.
- Le statut courant est sauvegardé dans le `project.json` persistant.
- En rouvrant l'application, le projet indique automatiquement le job en cours.
- L'interface interroge l'état toutes les 2 secondes et affiche une barre de progression.
- Pour Wan2.2, la progression affiche le segment courant lorsqu'il y en a plusieurs.
- Les 20 derniers jobs terminés sont conservés dans `jobHistory`.

### Important

La fermeture de **l'onglet ou de la fenêtre du navigateur** n'arrête plus une génération. En revanche, arrêter le processus Node (`./start.sh`), éteindre la machine ou redémarrer le serveur interrompt le job. Au redémarrage, un ancien job encore marqué `running` est automatiquement indiqué comme **interrompu**.

## Modes vidéo

- Auto
- Continu
- Long segments
- Safe

La durée finale est pilotée par le WAV.

## Démarrage

```bash
cp .env.example .env
./start.sh
```

Puis ouvrir :

```text
http://127.0.0.1:3010
```


## Nouveauté v0.4.1

- Affichage de l'avancement détaillé pour les vidéos Wan2.2 : pourcentage, segment courant/total, durée de vidéo déjà traitée, durée totale audio et estimation du temps restant.


## Nouveauté v0.4.2

- Suppression du timeout applicatif sur la génération **vidéo Wan2.2-S2V**.
- L'application attend désormais **sans limite de temps** la sortie vidéo de ComfyUI pour Wan2.2.
- Tant que ComfyUI continue de calculer, le job reste en cours au lieu d'échouer au bout de 90 minutes.


## Nouveauté v0.4.3

- Correction du mode **Continu** pour limiter la dérive du visage.
- Le mode continu n'envoie plus une seule génération vidéo géante à Wan2.2.
- Il utilise désormais des **blocs stabilisés d'au plus 8 secondes**, tous réancrés sur l'image originale de l'avatar.
- Résultat attendu : bien meilleure fidélité du visage, au prix de légers raccords possibles entre blocs.


## Nouveauté v0.4.4 — fidélité image source

- Nouveau mode **Image stricte** (par défaut) : aucun prompt positif n'est envoyé à Wan2.2-S2V.
- L'image importée est copiée telle quelle vers ComfyUI quand le cadrage **Original** est choisi : pas de resize, crop, sharpen ou conversion par l'étape vidéo.
- Prompt mouvement disponible uniquement en mode **Créatif**.
- Nouveau choix de cadrage : **Original**, **Fit**, **Crop**.
- Le négatif du mode strict renforce explicitement la lutte contre le changement d'identité et le face morphing.
- Le mode continu reste **stabilisé par blocs de 8 s** et la génération vidéo reste **sans timeout applicatif**.


## Nouveauté v0.4.5

- Le **nom du projet est obligatoire** à la création.
- Les dossiers projet portent maintenant un nom lisible : `Nom-du-projet--xxxxxxxx`.
- Les anciens projets stockés dans des dossiers UUID sont détectés et migrés automatiquement au démarrage.
- Les fichiers projet sont servis par l’ID interne, donc renommer un projet/dossier ne casse plus les aperçus.
- Le stockage reste externe à l’application via `DGX_AVATAR_DATA_DIR`.


## Nouveauté v0.5.0

- Nouveau moteur vidéo **Wav2Lip** intégré tout en gardant la même interface.
- Wav2Lip devient le moteur par défaut pour les avatars parlants, car il préserve mieux le visage d'une image source fournie par l'utilisateur.
- Wan2.2-S2V reste disponible comme moteur alternatif plus génératif.
- Nouvelle configuration `.env` : `WAV2LIP_DIR`, `WAV2LIP_PYTHON`, `WAV2LIP_CHECKPOINT`.


## Nouveauté v0.5.1

- Wan2.2-S2V reste le moteur de qualité principal.
- Modes Auto/Continu : blocs d'environ 10 secondes avec 0,75 s de chevauchement.
- Assemblage vidéo par `xfade` pour masquer les coupures entre blocs.
- La piste audio finale est le WAV original complet : pas de raccord audio AAC entre segments.


## Nouveauté v0.5.2

- Wan2.2 reste le moteur vidéo principal de qualité.
- Segments longs limités à environ **9,5 s** pour rester dans la zone où l'identité est la plus stable.
- **1,25 s de chevauchement audio/vidéo** entre segments.
- Remplacement du simple fondu par un **morphing optical-flow** frame par frame.
- Correction colorimétrique légère entre les deux segments avant morphing pour réduire les variations d'arrière-plan et d'exposition.
- Le **WAV original complet** est réinjecté à la fin pour éviter toute rupture audio.
- Le morphing utilise `MORPH_PYTHON`, par défaut le Python ComfyUI déjà équipé d'OpenCV sur le DGX Spark.

## v0.6.0 — Wan2.2 S2V Extend natif

- Suppression complète de Wav2Lip de l'application.
- Suppression du morphing / xfade externe pour les longues vidéos.
- Longue durée réalisée avec `WanSoundImageToVideoExtend` et `LatentConcat` natifs ComfyUI.
- Chunk officiel : 77 frames à 16 fps.
- Un seul WAV complet est encodé ; les extensions se décalent à partir du latent précédent.
- Le latent complet n'est décodé qu'une fois à la fin, puis la vidéo est coupée exactement à la durée audio.
- Aucun timeout applicatif sur la génération Wan2.2.


## Édition benchmark DGX Spark (v0.7.0-benchmark)

Interface : `http://127.0.0.1:3010/benchmark.html`

Cette page mesure le débit Wan2.2 avec la même paire image + WAV. Chaque répétition utilise un seed différent pour forcer un vrai sampling.

- mode séquentiel : un seul worker ComfyUI ;
- mode parallèle : 1 à 4 workers ComfyUI distincts ;
- nombre total de générations configurable ;
- temps global du batch + temps de chaque génération ;
- débit en jobs/minute ;
- journal JSON persistant dans `~/dgx-avatar-studio-data/benchmarks/logs`.

Pour démarrer jusqu'à 4 workers :

```bash
./scripts/start-benchmark-workers.sh 4
```

Pour couper uniquement les workers supplémentaires 8189-8191 :

```bash
./scripts/stop-benchmark-workers.sh
```

Attention : plusieurs workers chargent chacun leurs propres poids/activations sur le même DGX Spark. Le test peut donc saturer la mémoire unifiée à 3 ou 4 workers ; un échec/OOM est lui-même un résultat utile du benchmark.
