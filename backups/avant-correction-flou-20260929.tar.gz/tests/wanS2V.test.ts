import assert from "node:assert/strict";
import test from "node:test";
import { buildWanS2VExtendedWorkflow } from "../src/wanS2V.js";
import type { PromptGraph } from "../src/workflows.js";

const input = {
  imageName: "reference.png", audioName: "speech.wav", prompt: "",
  strictIdentity: true, seed: 123456
};

// Follow the latent all the way to the decoder. Temporal extensions must never
// multiply the number of independent videos, even for a long narration.
function latentShape(graph: PromptGraph, id: string): { batch: number; blocks: number } {
  const node = graph[id];
  const linked = (name: string) => latentShape(graph, (node.inputs[name] as [string, number])[0]);
  switch (node.class_type) {
    case "WanSoundImageToVideo": return { batch: Number(node.inputs.batch_size), blocks: 1 };
    case "WanSoundImageToVideoExtend": return { batch: linked("video_latent").batch, blocks: 1 };
    case "KSampler": return linked("latent_image");
    case "LatentConcat": {
      assert.equal(node.inputs.dim, "t");
      const a = linked("samples1"), b = linked("samples2");
      assert.equal(a.batch, b.batch);
      return { batch: a.batch, blocks: a.blocks + b.blocks };
    }
    default: throw new Error(`Unexpected latent node: ${node.class_type}`);
  }
}

for (const [durationSeconds, expectedBlocks] of [[1, 1], [77 / 16, 1], [78 / 16, 2], [10, 3], [60, 13]]) {
  test(`one output video covering ${durationSeconds}s of audio`, () => {
    const { graph, chunks, generatedFrames } = buildWanS2VExtendedWorkflow({ ...input, durationSeconds });
    const nodes = Object.values(graph);
    assert.equal(chunks, expectedBlocks);
    assert.ok(generatedFrames >= Math.ceil(durationSeconds * 16));
    assert.ok(generatedFrames - Math.ceil(durationSeconds * 16) < 77);
    const decoders = nodes.filter(node => node.class_type === "VAEDecode");
    assert.equal(decoders.length, 1);
    const latentId = (decoders[0].inputs.samples as [string, number])[0];
    assert.deepEqual(latentShape(graph, latentId), { batch: 1, blocks: expectedBlocks });
    assert.equal(nodes.filter(node => node.class_type === "AudioEncoderEncode").length, 1);
    assert.equal(nodes.filter(node => node.class_type === "SaveVideo").length, 1);
    const video = nodes.find(node => node.class_type === "CreateVideo")!;
    const audioId = (video.inputs.audio as [string, number])[0];
    assert.equal(graph[audioId].inputs.audio, "speech.wav");
    assert.equal(video.inputs.fps, 16);
    for (const node of nodes) {
      for (const value of Object.values(node.inputs)) {
        if (Array.isArray(value)) assert.ok(graph[value[0]], `Missing input node ${value[0]}`);
      }
      if (node.class_type === "KSampler") {
        assert.equal(node.inputs.steps, 20);
        assert.equal(node.inputs.cfg, 6);
        assert.equal(node.inputs.seed, input.seed);
        assert.equal(node.inputs.sampler_name, "uni_pc");
      }
      if (node.class_type === "WanSoundImageToVideo") {
        assert.equal(node.inputs.width, 768);
        assert.equal(node.inputs.height, 432);
      }
    }
  });
}

test("explicit quality and identity settings survive every extension", () => {
  const { graph } = buildWanS2VExtendedWorkflow({
    ...input, durationSeconds: 12, steps: 28, cfg: 5.5,
    width: 832, height: 480, filenamePrefix: "test/custom"
  });
  for (const node of Object.values(graph)) {
    if (node.class_type === "KSampler") {
      assert.equal(node.inputs.steps, 28);
      assert.equal(node.inputs.cfg, 5.5);
      const conditioning = graph[(node.inputs.positive as [string, number])[0]];
      const text = graph[(conditioning.inputs.positive as [string, number])[0]];
      assert.equal(text.inputs.text, "");
      const reference = graph[(conditioning.inputs.ref_image as [string, number])[0]];
      assert.equal(reference.inputs.image, input.imageName);
      const negative = graph[(conditioning.inputs.negative as [string, number])[0]];
      assert.match(String(negative.inputs.text), /identity change/);
    }
    if (node.class_type === "SaveVideo") assert.equal(node.inputs.filename_prefix, "test/custom");
  }
});
