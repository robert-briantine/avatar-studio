import type { PromptGraph } from "./workflows.js";

export const WAN_S2V_CHUNK_FRAMES = 77;
export const WAN_S2V_FPS = 16;

export const WAN_S2V_NODES = [
  "UNETLoader",
  "CLIPLoader",
  "VAELoader",
  "AudioEncoderLoader",
  "AudioEncoderEncode",
  "LoadAudio",
  "LoadImage",
  "CLIPTextEncode",
  "WanSoundImageToVideo",
  "WanSoundImageToVideoExtend",
  "ModelSamplingSD3",
  "KSampler",
  "LatentConcat",
  "VAEDecode",
  "CreateVideo",
  "SaveVideo"
] as const;

export const WAN_S2V_MODELS = {
  diffusion: "wan2.2_s2v_14B_fp8_scaled.safetensors",
  textEncoder: "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
  audioEncoder: "wav2vec2_large_english_fp16.safetensors",
  vae: "wan_2.1_vae.safetensors"
} as const;

/**
 * Workflow longue durée Wan2.2-S2V basé sur le mécanisme natif Extend de ComfyUI.
 *
 * Au lieu de générer plusieurs vidéos indépendantes puis de les raccorder :
 *   chunk initial -> Extend -> Extend -> ... -> décodage final unique.
 *
 * Chaque Extend reçoit le latent vidéo cumulé précédent. Le node natif utilise
 * les dernières frames du latent précédent comme référence de mouvement, ce qui
 * conserve bien mieux la continuité du visage, de la pose et du décor.
 */
export function buildWanS2VExtendedWorkflow(args: {
  imageName: string;
  audioName: string;
  prompt: string;
  strictIdentity?: boolean;
  seed: number;
  width?: number;
  height?: number;
  durationSeconds: number;
  steps?: number;
  cfg?: number;
  filenamePrefix?: string;
  chunkFrames?: number;
}): { graph: PromptGraph; chunks: number; generatedFrames: number } {
  const width = args.width ?? 768;
  const height = args.height ?? 432;
  const chunkFrames = args.chunkFrames ?? WAN_S2V_CHUNK_FRAMES;
  const requestedFrames = Math.max(1, Math.ceil(args.durationSeconds * WAN_S2V_FPS));
  const chunks = Math.max(1, Math.ceil(requestedFrames / chunkFrames));
  const generatedFrames = chunks * chunkFrames;
  const steps = args.steps ?? 20;
  const cfg = args.cfg ?? 6;

  const graph: PromptGraph = {
    "1": { class_type: "UNETLoader", inputs: { unet_name: WAN_S2V_MODELS.diffusion, weight_dtype: "default" } },
    "2": { class_type: "CLIPLoader", inputs: { clip_name: WAN_S2V_MODELS.textEncoder, type: "wan", device: "default" } },
    "3": { class_type: "VAELoader", inputs: { vae_name: WAN_S2V_MODELS.vae } },
    "4": { class_type: "AudioEncoderLoader", inputs: { audio_encoder_name: WAN_S2V_MODELS.audioEncoder } },
    "5": { class_type: "LoadAudio", inputs: { audio: args.audioName } },
    "6": { class_type: "AudioEncoderEncode", inputs: { audio_encoder: ["4", 0], audio: ["5", 0] } },
    "7": { class_type: "LoadImage", inputs: { image: args.imageName } },
    "8": { class_type: "CLIPTextEncode", inputs: { clip: ["2", 0], text: args.prompt } },
    "9": {
      class_type: "CLIPTextEncode",
      inputs: {
        clip: ["2", 0],
        text: args.strictIdentity
          ? "identity change, different person, different face, face morphing, facial drift, changed facial proportions, changed eyes, changed nose, changed jaw, distorted mouth, deformed face, duplicate face, extra limbs, subtitles, text, watermark, low quality, blurry"
          : "static image, frozen face, bad lip sync, distorted mouth, deformed face, duplicate face, extra limbs, subtitles, text, watermark, low quality, blurry"
      }
    },
    "10": { class_type: "ModelSamplingSD3", inputs: { model: ["1", 0], shift: 8 } },
    "11": {
      class_type: "WanSoundImageToVideo",
      inputs: {
        positive: ["8", 0],
        negative: ["9", 0],
        vae: ["3", 0],
        width,
        height,
        length: chunkFrames,
        // batch_size compte les vidéos indépendantes, pas les blocs temporels.
        // Extend conserve cette dimension : une seule vidéo suffit, les blocs
        // suivants sont ajoutés sur l'axe temporel par LatentConcat.
        batch_size: 1,
        audio_encoder_output: ["6", 0],
        ref_image: ["7", 0]
      }
    },
    "12": {
      class_type: "KSampler",
      inputs: {
        model: ["10", 0],
        positive: ["11", 0],
        negative: ["11", 1],
        latent_image: ["11", 2],
        seed: args.seed,
        steps,
        cfg,
        sampler_name: "uni_pc",
        scheduler: "simple",
        denoise: 1
      }
    }
  };

  // Le latent cumulé commence avec le premier chunk échantillonné.
  let fullLatentNode = "12";
  let nextNodeId = 20;

  for (let i = 1; i < chunks; i += 1) {
    const extendId = String(nextNodeId++);
    const samplerId = String(nextNodeId++);
    const concatId = String(nextNodeId++);

    graph[extendId] = {
      class_type: "WanSoundImageToVideoExtend",
      inputs: {
        positive: ["8", 0],
        negative: ["9", 0],
        vae: ["3", 0],
        length: chunkFrames,
        video_latent: [fullLatentNode, 0],
        audio_encoder_output: ["6", 0],
        ref_image: ["7", 0]
      }
    };

    graph[samplerId] = {
      class_type: "KSampler",
      inputs: {
        model: ["10", 0],
        positive: [extendId, 0],
        negative: [extendId, 1],
        latent_image: [extendId, 2],
        // Même seed pour garder un comportement aussi stable que possible.
        seed: args.seed,
        steps,
        cfg,
        sampler_name: "uni_pc",
        scheduler: "simple",
        denoise: 1
      }
    };

    graph[concatId] = {
      class_type: "LatentConcat",
      inputs: {
        samples1: [fullLatentNode, 0],
        samples2: [samplerId, 0],
        dim: "t"
      }
    };

    fullLatentNode = concatId;
  }

  const decodeId = String(nextNodeId++);
  const videoId = String(nextNodeId++);
  const saveId = String(nextNodeId++);

  graph[decodeId] = { class_type: "VAEDecode", inputs: { samples: [fullLatentNode, 0], vae: ["3", 0] } };
  graph[videoId] = { class_type: "CreateVideo", inputs: { images: [decodeId, 0], fps: WAN_S2V_FPS, audio: ["5", 0] } };
  graph[saveId] = {
    class_type: "SaveVideo",
    inputs: {
      video: [videoId, 0],
      filename_prefix: args.filenamePrefix ?? "dgx-avatar/wan-s2v-extended",
      format: "mp4",
      codec: "h264"
    }
  };

  return { graph, chunks, generatedFrames };
}
